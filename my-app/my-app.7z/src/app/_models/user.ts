export class User {
    id: number;
    name: string;
    firstname: string;
    password: string;
    address: string;
    email: string;
    date_inscription: Date;
    firstName: string;
}
