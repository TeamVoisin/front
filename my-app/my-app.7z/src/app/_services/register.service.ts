import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { User } from '../_models/user';
@Injectable()
export class RegisterService {
    userUrl='http://localhost:4200/register';


    constructor(private http: Http) { 
        //create user
        createUser(user:User)
    }
    
}