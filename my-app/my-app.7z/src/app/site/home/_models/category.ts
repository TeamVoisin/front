export class Category {
categoryLib: string;
   }
