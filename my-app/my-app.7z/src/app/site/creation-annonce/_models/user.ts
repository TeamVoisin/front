export class User {
    firstname: string;
}
