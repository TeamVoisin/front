import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creation-annonce',
  templateUrl: './creation-annonce.component.html',
  styleUrls: ['./creation-annonce.component.css']
})
export class CreationAnnonceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
